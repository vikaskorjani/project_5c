package rmi1;

import java.rmi.*;

public interface ReceiveMessageInterface extends Remote
{
    String receiveMessage(String x) throws RemoteException;

}