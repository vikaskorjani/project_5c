package rmi1;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.rmi.*;
//import java.rmi.RMISecurityManager;
import java.rmi.registry.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RmiClient
{
    String retVal;
    
    String sendRequest(String serverIP, String port,String command)
        {
        try{
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            String serverAddress =serverIP;//InetAddress.getLocalHost().getHostAddress();
            String serverPort = port;

            String path = "/home/monika/second_semester/OS/osproject/RMI1/";
            //System.out.println("sending 1" + command + " to " + serverAddress + ":" + serverPort);
            // get the �gregistry�h
            //Creates a stub for remote object registry
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            //System.out.println("sending 2" + command + " to " + serverAddress + ":" + serverPort);
            // look up the remote object
            rmiServer = (ReceiveMessageInterface) (registry.lookup("rmiServer"));
            // call the remote method
            System.out.println("sending 3" + command + " to " + serverAddress + ":" + serverPort);
            retVal = rmiServer.receiveMessage(command);
            System.out.println("Command Executed");
            //return retVal;

            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }

            return retVal;

        }
/*    static public void main(String args[])
    {

        FileOutputStream fs = null;
        try {
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            String serverAddress ="192.168.11.81";//InetAddress.getLocalHost().getHostAddress();
            String serverPort = "17000";
            
            String path = "/home/monika/second_semester/OS/osproject/RMI1/";
            String text = "sh param";
            System.out.println("sending " + text + " to " + serverAddress + ":" + serverPort);
            // get the �gregistry�h
            //Creates a stub for remote object registry
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            // look up the remote object
            rmiServer = (ReceiveMessageInterface) (registry.lookup("rmiServer"));
            // call the remote method
            String str = rmiServer.receiveMessage(text);
            System.out.println(str);
            
            FileWriter fstream = new FileWriter("out.txt");
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(str);
            out.close();

        }
        catch (Exception ex) {
            Logger.getLogger(RmiClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
        

    }*/
}