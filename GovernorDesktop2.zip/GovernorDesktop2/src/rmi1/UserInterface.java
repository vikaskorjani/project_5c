/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rmi1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dell
 */
public class UserInterface {

    public static void main(String args[])
    {
    String serverIP="192.168.11.81";
    String port = "19000";
    monitorPerformanceParam(serverIP,port);
    }

    static void monitorPerformanceParam(String serverIP,String port)
    {
        GovernorOrchastrator orch = new GovernorOrchastrator();
        String param = orch.monitorPerformanceParam(serverIP, port);
        createFile(param);

    }

    public static void createFile(String retVal)
    {
        FileWriter fstream = null;
        try {
            fstream = new FileWriter("out.txt");
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(retVal);
            out.close();
            System.out.println("File created");
        } catch (IOException ex) {
            Logger.getLogger(UserInterface.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fstream.close();
            } catch (IOException ex) {
                Logger.getLogger(UserInterface.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
