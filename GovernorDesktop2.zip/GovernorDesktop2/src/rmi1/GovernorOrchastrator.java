
package rmi1;

public class GovernorOrchastrator {

    public String monitorPerformanceParam(String serverIP, String port)
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(serverIP, port,"sh param");
    }

    public String monitorProcesses(String serverIP, String port)
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(serverIP, port,"top -b -n1");

    }

    public String monitorProcessTree(String serverIP, String port)
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(serverIP, port,"pstree");
    }
}
