package governordesktop2;

import rmi1.GovernorOrchastrator;

public class Multithreading implements Runnable
{
    Thread t;
    GovernorOrchastrator orch = new GovernorOrchastrator();
    public boolean finish;
    String serverIP,port;
    MonitoringWindow mw;

   public Multithreading(String tName,MonitoringWindow mwCalled)
   {
      // Create a new, second thread
      System.out.println(tName);
      String arr[] = tName.split(":");
      serverIP = arr[1];
      port = arr[2];
      mw = mwCalled;
      
      t = new Thread(this, tName);
      System.out.println("Child thread: " + t);
      t.start(); // Start the thread
   }

   // This is the entry point for the second thread.
   public void run()
   {
       String param;
       int mod;
       //MonitoringWindow mw = new MonitoringWindow(serverIP, port);

      try {
         while(!finish)
         {

            System.out.println("Child Thread"+t.getName());

            String arr[] = t.getName().split(":");
            mod = Integer.parseInt(arr[0]);
            
            if(mod == 0)
            {
                param = orch.monitorProcesses(serverIP, port);
                mw.printCommandOutput(param, 0);
                //Thread.sleep(100);
             }
            else if(mod == 1)
            {
               param = orch.monitorProcessTree(serverIP, port);
               mw.printCommandOutput(param, 1);
               //Thread.sleep(100);
             }
            // Let the thread sleep for a while.

            Thread.sleep(5000);
         }
     } catch (InterruptedException e) {
         System.out.println("Child interrupted.");
     }
     System.out.println("Exiting child thread.");
   }

   private void processThread()
   {
        System.out.println("processThread");
   }
   private void propertiesThread()
   {
    System.out.println("propertiesThread");
   }
}

