
package governordesktop2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;
import rmi1.UserInterface;

public class MonitoringWindow extends javax.swing.JFrame {

    int flag = 0;
    Multithreading mt1;
    String serverIP, port;

    /** Creates new form MonitoringWindow */
    public MonitoringWindow(String serverIPCalled, String portCalled)
    {
        serverIP = serverIPCalled;
        port = portCalled;
        initComponents();
    }

    ///MonitoringWindow()
    //{
    
    //}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jTextArea1.setColumns(200);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(200);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Processes", jPanel1);

        jTextArea2.setColumns(200);
        jTextArea2.setLineWrap(true);
        jTextArea2.setRows(200);
        jTextArea2.setWrapStyleWord(true);
        jScrollPane2.setViewportView(jTextArea2);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tabProcess Tree", jPanel2);

        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(178, Short.MAX_VALUE))
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        // TODO add your handling code here:
             if(flag == 1)
                mt1.finish = true;

        if(jTabbedPane1.getSelectedIndex() == 0)
        {
             jLabel1.setText("Processes Selected");
             String tName = 0+":"+serverIP+":"+port;
             mt1 = new Multithreading(tName,this);
             flag = 1;
         }
        else if(jTabbedPane1.getSelectedIndex() == 1)
        {
            jLabel1.setText("Properties Selected");
            String tName = 1+":"+serverIP+":"+port;
             mt1 = new Multithreading(tName,this);
            flag = 1;
        }
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        jTextArea1.setText("Default Text");
        jTextArea2.setText("Default Text");

        String tName = 0+":"+serverIP+":"+port;
        mt1 = new Multithreading(tName,this);
        flag = 1;
    }//GEN-LAST:event_formWindowOpened

    private void commands()
    {
        FileInputStream fs = null;
        try {
            fs = new FileInputStream("out.txt");
            System.out.println("File read");
            InputStreamReader ir = new InputStreamReader(fs); //Accpets object of any class that extends InputStream
            BufferedReader br = new BufferedReader(ir);
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("Here");
                
                //jTextArea1.setText(line);
                //jTextArea2.setText(line);
            }
        } 
        catch (Exception ex) {
            Logger.getLogger(MonitoringWindow.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fs.close();
            } catch (IOException ex) {
                Logger.getLogger(MonitoringWindow.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void printCommandOutput(String param, int index)
    {
        //UserInterface.createFile(param);
        //commands();
        System.out.println(param);
        jTextArea1.setText(param);
        jTextArea2.setText(param);
     }

    public static void displayMonitoring(final String serverIP, final String port)
    {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MonitoringWindow(serverIP,port).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables

}
