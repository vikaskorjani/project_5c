/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PolicyManager;

import java.io.Serializable;

/**
 *
 * @author jatin_c
 */
public class PolicyItem implements Serializable{

    private String service_name;
    private String process_name;
    private boolean isService;
    private boolean isProcess;
    private String event;
    private String action;
    private int threshold_value;

    /**
     * @return the service_name
     */
    public String getService_name() {
        return service_name;
    }

    /**
     * @param service_name the service_name to set
     */
    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    /**
     * @return the process_name
     */
    public String getProcess_name() {
        return process_name;
    }

    /**
     * @param process_name the process_name to set
     */
    public void setProcess_name(String process_name) {
        this.process_name = process_name;
    }

    /**
     * @return the isService
     */
    public boolean isIsService() {
        return isService;
    }

    /**
     * @param isService the isService to set
     */
    public void setIsService(boolean isService) {
        this.isService = isService;
    }

    /**
     * @return the isProcess
     */
    public boolean isIsProcess() {
        return isProcess;
    }

    /**
     * @param isProcess the isProcess to set
     */
    public void setIsProcess(boolean isProcess) {
        this.isProcess = isProcess;
    }

    /**
     * @return the event
     */
    public String getEvent() {
        return event;
    }

    /**
     * @param event the event to set
     */
    public void setEvent(String event) {
        this.event = event;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * @return the threshold_value
     */
    public int getThreshold_value() {
        return threshold_value;
    }

    /**
     * @param threshold_value the threshold_value to set
     */
    public void setThreshold_value(int threshold_value) {
        this.threshold_value = threshold_value;
    }

public static PolicyItem setServicePolicyItem(String name, String event, String action){

    PolicyItem pi = new PolicyItem();

    pi.setService_name(name);
    pi.setEvent(event);
    pi.setAction(action);
    pi.setIsService(true);
    pi.setIsProcess(false);
    return pi;

}

public static PolicyItem setProcessPolicyItem(String name, String event, int threshold_value,String action){
     PolicyItem pi = new PolicyItem();

    pi.setProcess_name(name);
    pi.setEvent(event);
    pi.setAction(action);
    pi.setThreshold_value(threshold_value);
    pi.setIsService(false);
    pi.setIsProcess(true);
    return pi;
}

}
