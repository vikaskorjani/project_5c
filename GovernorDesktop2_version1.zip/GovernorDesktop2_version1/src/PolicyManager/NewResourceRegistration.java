/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PolicyManager;

import java.awt.Container;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author jatin_c
 */
public class NewResourceRegistration extends JFrame{
    private javax.swing.JTextField ipAddress;
    private javax.swing.JTextField portNo;
    private javax.swing.JTextField utilization[];
    private javax.swing.JCheckBox jCBox[];
    private javax.swing.JRadioButton jRadioButton1[];
    private javax.swing.JLabel jLabel[];
    private javax.swing.JLabel jL[];
    private javax.swing.JRadioButton jRadioButton2[];
    private javax.swing.JButton jButton1;

    static int row = 0;
    static int index = 0;
    static int textBaseX = 100;
    static int textBaseY = 50;
    static Container panel;


    public NewResourceRegistration(String[] services){

         initComponents(services);
    }

    public NewResourceRegistration(String[] services, String name, String IP, String port){

         initComponents(services,name, IP, port);
    }

     private void initComponents(final String[] services) {

        int i;
        this.setSize(1200,500);
        panel = this.getContentPane();
        panel.setLayout(null);



        jL = new JLabel[6];

        jL[0] = new JLabel("Resource IP Adress");
        jL[0].setLocation(50,10);
        jL[0].setSize(200,20);
        panel.add(jL[0]);

        jL[1] = new JLabel("Port No");
        jL[1].setLocation(300,10);
        jL[1].setSize(70,20);
        panel.add(jL[1]);

        jL[2] = new JLabel("Service/Process");
        jL[2].setLocation(400,10);
        jL[2].setSize(150,20);
        panel.add(jL[2]);


        jL[3] = new JLabel("Event");
        jL[3].setLocation(600,10);
        jL[3].setSize(100,20);
        panel.add(jL[3]);

        jL[4] = new JLabel("Active Action");
        jL[4].setLocation(1050,10);
        jL[4].setSize(130,20);
        panel.add(jL[4]);

        jL[5] = new JLabel("Passive Action");
        jL[5].setLocation(900,10);
        jL[5].setSize(130,20);
        panel.add(jL[5]);

        ipAddress = new javax.swing.JTextField();
        ipAddress.setText("Enter IP Address");
        ipAddress.setSize(200,20);
        ipAddress.setLocation(50,50);
        ipAddress.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ipAddressMouseClicked(evt);
            }

            private void ipAddressMouseClicked(MouseEvent evt) {
                ipAddress.setText(null);
            }
        });
        panel.add(ipAddress);
      

        portNo = new javax.swing.JTextField();
        portNo.setText("PortNo");
        portNo.setSize(50,20);
        portNo.setLocation(300, 50);
        portNo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                portNoMouseClicked(evt);
            }

            private void portNoMouseClicked(MouseEvent evt) {
                portNo.setText(null);
            }
        });
        

        panel.add(portNo);

        jCBox = new JCheckBox[(services.length + 2)];
        jRadioButton1 = new JRadioButton[(services.length + 2)];
        jLabel = new JLabel[(services.length + 2)];
        jRadioButton2 = new JRadioButton[(services.length + 2)];
        utilization = new JTextField[2];
        for( i=0;i<services.length;i++){

            System.out.println("\n" + i +": "+ services[i]);

            jCBox[i] = new JCheckBox();
            jCBox[i].setText(services[i]);
            jCBox[i].setLocation(400, textBaseY);
            jCBox[i].setSize(150,20);
            panel.add(jCBox[i]);

            jLabel[i]= new JLabel();
            jLabel[i].setText("On Stop");
            jLabel[i].setLocation(600, textBaseY);
            jLabel[i].setSize(100,20);
            panel.add(jLabel[i]);

            jRadioButton1[i] = new JRadioButton();
            jRadioButton1[i].setText("Restart");
            jRadioButton1[i].setLocation(1050,textBaseY);
            jRadioButton1[i].setSize(100,20);
            panel.add(jRadioButton1[i]);
    
            jRadioButton2[i] = new JRadioButton();
            jRadioButton2[i].setText("Notify");
             jRadioButton2[i].setLocation(900,textBaseY);
            jRadioButton2[i].setSize(100,20);
            panel.add(jRadioButton2[i]);
            textBaseY += 30;
        }

            jCBox[i] = new JCheckBox();
            jCBox[i].setText("For all Processes");
            jCBox[i].setLocation(400, textBaseY);
            jCBox[i].setSize(150,20);
            panel.add(jCBox[i]);

            jLabel[i]= new JLabel();
            jLabel[i].setText(" % CPU Utilization > ");
            jLabel[i].setLocation(600, textBaseY);
            jLabel[i].setSize(150,20);
            panel.add(jLabel[i]);

            utilization[0] = new JTextField();
            utilization[0].setLocation(800, textBaseY);
            utilization[0].setSize(50, 20);
            utilization[0].setText("%");
            panel.add(utilization[0]);

            jRadioButton1[i] = new JRadioButton();
            jRadioButton1[i].setText("Notify");
            jRadioButton1[i].setLocation(900,textBaseY);
            jRadioButton1[i].setSelected(true);
            jRadioButton1[i].setEnabled(false);
            jRadioButton1[i].setSize(100,20);
           
             panel.add(jRadioButton1[i]);

             utilization[0].addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                utilization0MouseClicked(evt);
            }

            private void utilization0MouseClicked(MouseEvent evt) {
                utilization[0].setText(null);
                
            }
        });

        i++;
        textBaseY += 30;

            jCBox[i] = new JCheckBox();
            jCBox[i].setText("For all Processes");
            jCBox[i].setLocation(400, textBaseY);
            jCBox[i].setSize(150,20);
            panel.add(jCBox[i]);

            jLabel[i]= new JLabel();
            jLabel[i].setText(" % Memory Utilization > ");
            jLabel[i].setLocation(600, textBaseY);
            jLabel[i].setSize(200,20);
            panel.add(jLabel[i]);

            utilization[1] = new JTextField();
            utilization[1].setLocation(800, textBaseY);
            utilization[1].setSize(50, 20);
            utilization[1].setText("%");
            panel.add(utilization[1]);

            jRadioButton1[i] = new JRadioButton();
            jRadioButton1[i].setText("Notify");
            jRadioButton1[i].setLocation(900,textBaseY);
            jRadioButton1[i].setSelected(true);
            jRadioButton1[i].setEnabled(false);
            jRadioButton1[i].setSize(100,20);

             panel.add(jRadioButton1[i]);

             utilization[1].addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                utilization1MouseClicked(evt);
            }

            private void utilization1MouseClicked(MouseEvent evt) {
                utilization[1].setText(null);

            }
        });



       
        jButton1 = new javax.swing.JButton();
        jButton1.setText("Register Resource");
        jButton1.setSize(200,20);
        jButton1.setLocation(50,110);
        panel.add(jButton1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }

            private void jButton1MouseClicked(MouseEvent evt) {


                Policy p = new Policy();

                p.setName(null);
                p.setIpAddress(ipAddress.getText());

                p.setPortNo(portNo.getText());

                ArrayList<PolicyItem> piList = new ArrayList<PolicyItem>();
                int i;

                for( i = 0;i< services.length;i++){
                    if(jCBox[i].isSelected())
                    {


                        System.out.println(jCBox[i].getText() + jLabel[i].getText());

                        if(jRadioButton1[i].isSelected()){
                             System.out.println(jRadioButton1[i].getText());
                            piList.add(PolicyItem.setServicePolicyItem(jCBox[i].getText(), jLabel[i].getText(), jRadioButton1[i].getText()));

                        }


                        if(jRadioButton2[i].isSelected()){
                             System.out.println(jRadioButton2[i].getText());
                             piList.add(PolicyItem.setServicePolicyItem(jCBox[i].getText(), jLabel[i].getText(), jRadioButton2[i].getText()));
                             
                        }

                }
            }

                for(;i<(services.length + 2);i++){

                     if(jCBox[i].isSelected()){

                          System.out.println(jCBox[i].getText() + jLabel[i].getText());

                        if(jRadioButton1[i].isSelected()){
                             System.out.println(jRadioButton1[i].getText());
                            piList.add(PolicyItem.setProcessPolicyItem(jCBox[i].getText(), jLabel[i].getText(), Integer.parseInt(utilization[(i - services.length)].getText()),jRadioButton1[i].getText()));

                        }

                     }

                }

                p.setPolicyItems(piList);

                try{

		FileOutputStream fout = new FileOutputStream(ipAddress.getText()+ ".data");
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		oos.writeObject(p);
		oos.close();
		System.out.println("Done");



                System.out.println("Reading file");

                Policy p2 = Policy.policyFileReader(ipAddress.getText() + ".data");
                System.out.println("Name:" + p2.getName() );
                System.out.println("IP Address" + p2.getIpAddress());
                System.out.println("PortNo:" + p2.getPortNo());

                    for(PolicyItem pit : p2.getPolicyItems()){

                   if(pit.isIsProcess()){
                   System.out.println("Process:" + pit.getProcess_name() + "  Event " + pit.getEvent() +"  " + pit.getThreshold_value()+ " Action " + pit.getAction());
                   }
                    if(pit.isIsService()){
                   System.out.println("Service:" + pit.getService_name() + "  Event " + pit.getEvent() +" Action " + pit.getAction());
                   }
                    }

	   }catch(Exception ex){
		   ex.printStackTrace();
	   }


                }
        });

               
    }

     private void initComponents(final String[] services,final String name, String IP, String port ) {

        int i;
        this.setSize(1200,500);
        panel = this.getContentPane();
        panel.setLayout(null);



        jL = new JLabel[6];

        jL[0] = new JLabel("Resource IP Adress");
        jL[0].setLocation(50,10);
        jL[0].setSize(200,20);
        panel.add(jL[0]);

        jL[1] = new JLabel("Port No");
        jL[1].setLocation(300,10);
        jL[1].setSize(70,20);
        panel.add(jL[1]);

        jL[2] = new JLabel("Service/Process");
        jL[2].setLocation(400,10);
        jL[2].setSize(150,20);
        panel.add(jL[2]);


        jL[3] = new JLabel("Event");
        jL[3].setLocation(600,10);
        jL[3].setSize(100,20);
        panel.add(jL[3]);

        jL[4] = new JLabel("Active Action");
        jL[4].setLocation(1050,10);
        jL[4].setSize(130,20);
        panel.add(jL[4]);

        jL[5] = new JLabel("Passive Action");
        jL[5].setLocation(900,10);
        jL[5].setSize(130,20);
        panel.add(jL[5]);

        ipAddress = new javax.swing.JTextField();
        ipAddress.setText(IP);
        ipAddress.setSize(200,20);
        ipAddress.setLocation(50,50);
        ipAddress.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ipAddressMouseClicked(evt);
            }

            private void ipAddressMouseClicked(MouseEvent evt) {
                ipAddress.setText(null);
            }
        });
        panel.add(ipAddress);


        portNo = new javax.swing.JTextField();
        portNo.setText(port);
        portNo.setSize(50,20);
        portNo.setLocation(300, 50);
        portNo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                portNoMouseClicked(evt);
            }

            private void portNoMouseClicked(MouseEvent evt) {
                portNo.setText(null);
            }
        });


        panel.add(portNo);

        jCBox = new JCheckBox[(services.length + 2)];
        jRadioButton1 = new JRadioButton[(services.length + 2)];
        jLabel = new JLabel[(services.length + 2)];
        jRadioButton2 = new JRadioButton[(services.length + 2)];
        utilization = new JTextField[2];
        for( i=0;i<services.length;i++){

            System.out.println("\n" + i +": "+ services[i]);

            jCBox[i] = new JCheckBox();
            jCBox[i].setText(services[i]);
            jCBox[i].setLocation(400, textBaseY);
            jCBox[i].setSize(150,20);
            panel.add(jCBox[i]);

            jLabel[i]= new JLabel();
            jLabel[i].setText("On Stop");
            jLabel[i].setLocation(600, textBaseY);
            jLabel[i].setSize(100,20);
            panel.add(jLabel[i]);

            jRadioButton1[i] = new JRadioButton();
            jRadioButton1[i].setText("Restart");
            jRadioButton1[i].setLocation(1050,textBaseY);
            jRadioButton1[i].setSize(100,20);
            panel.add(jRadioButton1[i]);

            jRadioButton2[i] = new JRadioButton();
            jRadioButton2[i].setText("Notify");
             jRadioButton2[i].setLocation(900,textBaseY);
            jRadioButton2[i].setSize(100,20);
            panel.add(jRadioButton2[i]);
            textBaseY += 30;
        }

            jCBox[i] = new JCheckBox();
            jCBox[i].setText("For all Processes");
            jCBox[i].setLocation(400, textBaseY);
            jCBox[i].setSize(150,20);
            panel.add(jCBox[i]);

            jLabel[i]= new JLabel();
            jLabel[i].setText(" % CPU Utilization > ");
            jLabel[i].setLocation(600, textBaseY);
            jLabel[i].setSize(150,20);
            panel.add(jLabel[i]);

            utilization[0] = new JTextField();
            utilization[0].setLocation(800, textBaseY);
            utilization[0].setSize(50, 20);
            utilization[0].setText("%");
            panel.add(utilization[0]);

            jRadioButton1[i] = new JRadioButton();
            jRadioButton1[i].setText("Notify");
            jRadioButton1[i].setLocation(900,textBaseY);
            jRadioButton1[i].setSelected(true);
            jRadioButton1[i].setEnabled(false);
            jRadioButton1[i].setSize(100,20);

             panel.add(jRadioButton1[i]);

             utilization[0].addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                utilization0MouseClicked(evt);
            }

            private void utilization0MouseClicked(MouseEvent evt) {
                utilization[0].setText(null);

            }
        });

        i++;
        textBaseY += 30;

            jCBox[i] = new JCheckBox();
            jCBox[i].setText("For all Processes");
            jCBox[i].setLocation(400, textBaseY);
            jCBox[i].setSize(150,20);
            panel.add(jCBox[i]);

            jLabel[i]= new JLabel();
            jLabel[i].setText(" % Memory Utilization > ");
            jLabel[i].setLocation(600, textBaseY);
            jLabel[i].setSize(200,20);
            panel.add(jLabel[i]);

            utilization[1] = new JTextField();
            utilization[1].setLocation(800, textBaseY);
            utilization[1].setSize(50, 20);
            utilization[1].setText("%");
            panel.add(utilization[1]);

            jRadioButton1[i] = new JRadioButton();
            jRadioButton1[i].setText("Notify");
            jRadioButton1[i].setLocation(900,textBaseY);
            jRadioButton1[i].setSelected(true);
            jRadioButton1[i].setEnabled(false);
            jRadioButton1[i].setSize(100,20);

             panel.add(jRadioButton1[i]);

             utilization[1].addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                utilization1MouseClicked(evt);
            }

            private void utilization1MouseClicked(MouseEvent evt) {
                utilization[1].setText(null);

            }
        });




        jButton1 = new javax.swing.JButton();
        jButton1.setText("Register Resource");
        jButton1.setSize(200,20);
        jButton1.setLocation(50,110);
        panel.add(jButton1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }

            private void jButton1MouseClicked(MouseEvent evt) {


                Policy p = new Policy();

                p.setName(name);
                p.setIpAddress(ipAddress.getText());

                p.setPortNo(portNo.getText());

                ArrayList<PolicyItem> piList = new ArrayList<PolicyItem>();
                int i;

                for( i = 0;i< services.length;i++){
                    if(jCBox[i].isSelected())
                    {


                        System.out.println(jCBox[i].getText() + jLabel[i].getText());

                        if(jRadioButton1[i].isSelected()){
                             System.out.println(jRadioButton1[i].getText());
                            piList.add(PolicyItem.setServicePolicyItem(jCBox[i].getText(), jLabel[i].getText(), jRadioButton1[i].getText()));

                        }


                        if(jRadioButton2[i].isSelected()){
                             System.out.println(jRadioButton2[i].getText());
                             piList.add(PolicyItem.setServicePolicyItem(jCBox[i].getText(), jLabel[i].getText(), jRadioButton2[i].getText()));

                        }

                }
            }

                for(;i<(services.length + 2);i++){

                     if(jCBox[i].isSelected()){

                          System.out.println(jCBox[i].getText() + jLabel[i].getText());

                        if(jRadioButton1[i].isSelected()){
                             System.out.println(jRadioButton1[i].getText());
                            piList.add(PolicyItem.setProcessPolicyItem(jCBox[i].getText(), jLabel[i].getText(), Integer.parseInt(utilization[(i - services.length)].getText()),jRadioButton1[i].getText()));

                        }

                     }

                }

                p.setPolicyItems(piList);

                try{

		FileOutputStream fout = new FileOutputStream(ipAddress.getText()+ ".data");
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		oos.writeObject(p);
		oos.close();
		System.out.println("Done");



                System.out.println("Reading file");

                Policy p2 = Policy.policyFileReader(ipAddress.getText() + ".data");
                System.out.println("Name:" + p2.getName() );
                System.out.println("IP Address" + p2.getIpAddress());
                System.out.println("PortNo:" + p2.getPortNo());

                    for(PolicyItem pit : p2.getPolicyItems()){

                   if(pit.isIsProcess()){
                   System.out.println("Process:" + pit.getProcess_name() + "  Event " + pit.getEvent() +"  " + pit.getThreshold_value()+ " Action " + pit.getAction());
                   }
                    if(pit.isIsService()){
                   System.out.println("Service:" + pit.getService_name() + "  Event " + pit.getEvent() +" Action " + pit.getAction());
                   }
                    }

	   }catch(Exception ex){
		   ex.printStackTrace();
	   }


                }
        });


    }

 public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                String[] services = {"mySql","Apache Tomcat","Test Services"};

                new NewResourceRegistration(services).setVisible(true);

                //new NewResourceRegistration(services,"jatin-PC","192.16.11.50","9075").setVisible(true);
            }
        });
    }
}
