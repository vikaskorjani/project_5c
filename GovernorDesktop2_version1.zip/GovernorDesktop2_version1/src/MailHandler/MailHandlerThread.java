/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MailHandler;

import NetworkCommManager.RmiClient;
import Reporting.Report;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;

public class MailHandlerThread implements Runnable
{

        BufferedReader reader;
        String result,sender;
        RmiClient newClient;
        public boolean autPilotStatus;
        GmailReader gr;

        public MailHandlerThread()
        {
            autPilotStatus = true;
            reader = new BufferedReader(new InputStreamReader(System.in));
            newClient = new RmiClient();
            gr = new GmailReader();
            
        }

        public void run()
            {
                System.out.println("AutoPilot Thread Started");

                while(autPilotStatus)
                {
                    System.out.println("AutoPilot Thread Running");
                try
                {
                    ArrayList<Message> message = gr.getMessages();
                    for (Message m : message) {
                        System.out.println(m.getSubject());
                        String[] parts = m.getSubject().split(":");
                        newClient.setServerAddress(parts[0]);
                        newClient.setServerPort(parts[1]);
                        newClient.setRequest(parts[2]);
                        sender = m.getFrom()[0].toString();
                        result = newClient.executeRequest();
                        Report newReport = new Report();
                        newReport.sendReportAttachment(sender, result, "ReportFromRSC.txt");
                        Thread.sleep(10000);
                    }
                } catch (Exception ex) {
                    Logger.getLogger(MailHandlerThread.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
                newClient.setRequest(null);
                System.out.println("AutoPilot Thread Stopped");
        }

}
