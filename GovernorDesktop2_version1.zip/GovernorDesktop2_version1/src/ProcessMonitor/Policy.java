
package ProcessMonitor;

class Policy
{
    public String type; //Service or Process
    public String property; // service name(service) or CPU/MEM (process)
    public String event; // onStop (service) or 5%/10% (processes)
    public int action1,action2; // action1 for
}

