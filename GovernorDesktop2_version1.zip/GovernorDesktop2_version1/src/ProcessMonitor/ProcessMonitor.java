
package ProcessMonitor;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ProcessMonitor {
    public static boolean noSystemRegistered;

    public ArrayList<Entry> readRegisteredSystemInfo()
    {
        noSystemRegistered = false;
        FileInputStream fs = null;
        ArrayList <Entry> entries = new ArrayList<Entry>();
        try
        {
            fs = new FileInputStream("registration.txt");
            System.out.println("Registration File read ");
            InputStreamReader ir = new InputStreamReader(fs);//Accpets object of any class that extends InputStream
            BufferedReader br = new BufferedReader(ir);
            
            String line;
            while((line = br.readLine()) != null)
                {
                    String arr[] = line.split(":");
                    Entry e = new Entry();
                    e.setRegName(arr[0]);
                    e.setServerIP(arr[1]);
                    e.setServerPort(arr[2]);
                    entries.add(e);

                }

        }
        catch(Exception e)
            {
                noSystemRegistered = true;
            }
        try {
            fs.close();
        } catch (IOException ex) {
            noSystemRegistered = true;
            Logger.getLogger(ProcessMonitor.class.getName()).log(Level.SEVERE, null, ex);
        }
            System.out.println("Registration File closed");

        return entries;
    }

    public static ArrayList<ProcFileEntry> readProcFileInfo(String fileName)
    {
        
        FileInputStream fs = null;
        String line = null;
        BufferedReader br = null;
        InputStreamReader ir;
        ArrayList <ProcFileEntry> entries = new ArrayList<ProcFileEntry>();
        try
        {

            fs = new FileInputStream("Proc/"+fileName);
            System.out.println("Proc File read  : "+ fileName);
            ir = new InputStreamReader(fs);//Accpets object of any class that extends InputStream
            br = new BufferedReader(ir);

            int flag = 0;
            while(flag == 0)
            {
                line = br.readLine();
                String arr[] = line.split("\\s+");
                if(arr[1].equals("PID"))
                    flag = 1;
            }
            
        }
            catch(Exception e)
            {
            }
        try {
            line = br.readLine();
            while((line = br.readLine()) != null)
                {                    
                    if(!line.isEmpty())
                    {
                    String arr[] = line.split("\\s+");
                    
                    ProcFileEntry e = new ProcFileEntry();
                    e.PID = arr[1].trim();
                    e.USER = arr[2].trim();
                    e.PR = arr[3].trim();
                    e.NI = arr[4].trim();
                    e.VIRT = arr[5].trim();
                    e.RES = arr[6].trim();
                    e.SHR = arr[7].trim();
                    e.S = arr[8].trim();
                    e.CPU = arr[9].trim();
                    e.MEM = arr[10].trim();
                    e.TIME = arr[11].trim();
                    e.COMMAND = arr[12].trim();
                    //System.out.println(line);
                    entries.add(e);
                    }
      
                }

            fs.close();
        } catch (IOException ex) {
            Logger.getLogger(ProcessMonitor.class.getName()).log(Level.SEVERE, null, ex);
        }
            System.out.println("Proc File closed"+fileName);

        return entries;
    }

    void createThreads()
    {
        noSystemRegistered = false;
        ArrayList <Entry> entries = readRegisteredSystemInfo();
        
        if(!noSystemRegistered)
        {
            AutoMonitoringThread[] mt = new AutoMonitoringThread[entries.size()];
            int i = 0;
            System.out.println("Creating Threads");
            for(Entry e:entries)
            {
                System.out.println("Starting Thread : "+e.getRegName()+":"+e.getServerIP()+":"+e.getServerPort());
                mt[i] = new AutoMonitoringThread(e.getRegName(),e.getServerIP(),e.getServerPort(),i);
                i++;
            }
            System.out.println(i+" Threads Created");
        }
        else
        {
            System.out.println("No System Registered");
        }
    }

    public void startAutoMonitoring()
    {
        System.out.println("AutoMonitoring started");
        createThreads();
        
    }
}
