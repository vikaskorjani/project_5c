/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ProcessMonitor;

import NetworkCommManager.RmiClient;
import Reporting.Report;
import governordesktop2.DataFrame;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;



public class AutoMonitoringThread implements Runnable{

    String regName;
    String serverIP;
    String serverPort;
    RmiClient rmiclient;
    public static boolean finishAll = false;
    public static int countAutoMonitThreads;
    String retVal;
    Thread t;
    int time;
    int rowIndex;
    String logEntries;
    ArrayList <ProcFileEntry> notifyEntries;
    ArrayList <ProcFileEntry> restartEntries;


    public AutoMonitoringThread(){}
    public AutoMonitoringThread(String regNameParam,String serverIPParam, String serverPortParam,int indexParam)
    {
      regName = regNameParam;
      serverIP = serverIPParam;
      serverPort = serverPortParam;
      rowIndex = indexParam;
      rmiclient = new RmiClient();
      retVal = "DEFAULT";
      t = new Thread(this, regName);
      time = 10;
      countAutoMonitThreads++;
      notifyEntries = new ArrayList<ProcFileEntry>();
      restartEntries = new ArrayList<ProcFileEntry>();
      t.start();
    }
    public void run()
    {
        try {
            while(!finishAll)
            {
                System.out.println("Thread : "+regName+":"+serverIP+":"+serverPort);
                try {
                    retVal = rmiclient.sendRequest(regName, serverIP, serverPort, "top -b -n1");                    
                    System.out.println(retVal);
                } catch (Exception ex)
                {
                    retVal = "NOT DEFAULT";
                    DataFrame.reflectOfflineResource(rowIndex);
                }
                if(!retVal.equals("DEFAULT"))
                {
                    logEntries = "";
                    System.out.println(retVal + "In IF");
                    DataFrame.reflectOnlineResource(rowIndex);
                    Report rt = new Report();
                    rt.createMonitoringFile(retVal, regName+"Proc.txt");
                    regName = "jatin";
                    ArrayList <ProcFileEntry> entries = ProcessMonitor.readProcFileInfo(regName+"Proc.txt");

                    
                    ArrayList <Policy> listPolicies = readPolicies(regName+"Policy.txt");

                    for(ProcFileEntry e : entries)
                    {
                            for(Policy p : listPolicies)
                            {
                                if(p.type.equals("service") && e.COMMAND.equals(p.property))
                                {
                                    if(p.action1 == 1 && !notifyEntries.contains(e))
                                    {
                                        notifyEntries.add(e);
                                        logEntries = logEntries+"\n"+"Service " + e.PID+":"+e.COMMAND+":"+"was stopped";
                                    }
                                    if(p.action2 == 1 && !restartEntries.contains(e))
                                    {
                                        restartEntries.add(e);
                                        logEntries = logEntries+"\n"+"Service " + e.PID+":"+e.COMMAND+":"+"was restarted";
                                    }
                                }
                                 else if(p.type.equals("process"))
                                 {
                                    if(p.property.equals("CPU") && (Float.parseFloat(e.CPU) > Float.parseFloat(p.event)) && !notifyEntries.contains(e))
                                    {
                                        notifyEntries.add(e);
                                        logEntries = logEntries+"\n"+"Process " + e.PID+":"+e.COMMAND+":"+e.CPU+" has exceeded the CPU utilization limit";
                                     }
                                    else if(p.property.equals("MEM") && (Float.parseFloat(e.MEM) > Float.parseFloat(p.event)) && !notifyEntries.contains(e))
                                    {
                                        notifyEntries.add(e);                                    
                                        logEntries = logEntries+"\n"+"Process " + e.PID+":"+e.COMMAND+":"+e.MEM+" has exceeded the Memory utilization limit";
                                    }
                                 }
                            }
                            
                    }

                    Report log = new Report();
                    rt.addToFile(logEntries, "Log/log.txt");

                    System.out.println("NOTIFY ENTRIES");
                    for(ProcFileEntry e : notifyEntries)
                    {
                        System.out.println(e.PID);
                   }
                    System.out.println("RESTART ENTRIES");

                    for(ProcFileEntry e : restartEntries)
                    {
                        System.out.println(e.PID);
                   }

              }
                retVal = "DEFAULT";
                Thread.sleep(time);
            }
            System.out.println("Thread Stopped: "+regName+":"+serverIP+":"+serverPort);

        } catch (InterruptedException ex) {
            Logger.getLogger(AutoMonitoringThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    ArrayList <Policy> readPolicies(String filename)
    {
        ArrayList<Policy> listPolicies = new ArrayList<Policy>();
        FileInputStream fs = null;
        try {
            
            fs = new FileInputStream("Policy/"+filename);
            System.out.println("Policy File read ");
            InputStreamReader ir = new InputStreamReader(fs); //Accpets object of any class that extends InputStream
            BufferedReader br = new BufferedReader(ir);
            String line;

            while ((line = br.readLine()) != null)
            {
                String[] arr = line.split(":");
                Policy p = new Policy();
                p.type = arr[0];
                p.property = arr[1];
                p.event = arr[2];
                p.action1 = Integer.parseInt(arr[3]);
                p.action2 = Integer.parseInt(arr[4]);
                listPolicies.add(p);
            }
            

        } catch (IOException ex) {
            Logger.getLogger(AutoMonitoringThread.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fs.close();
            } catch (IOException ex) {
                Logger.getLogger(AutoMonitoringThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return listPolicies;
    }

}
