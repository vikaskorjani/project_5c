
package ProcessMonitor;


public class StartPMThread implements Runnable{
    Thread t = null;
    public boolean finish = false;

    public StartPMThread()
    {
        t = new Thread(this, "ProcessMonitorThread");
        t.start();
    }
    public void run()
    {
        System.out.println("SPM Thread created");
        ProcessMonitor pm = new ProcessMonitor();
        pm.startAutoMonitoring();
        while(!finish);
        
        if(ProcessMonitor.noSystemRegistered == false)
            AutoMonitoringThread.finishAll = true;

        System.out.println("SPM Thread finished");
    }

}
