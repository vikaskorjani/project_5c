/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Reporting;

import MailHandler.GmailSender;
import ProcessMonitor.Entry;
import ProcessMonitor.ProcessMonitor;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author root
 */
public class Report {

    public void addToFile(String text, String fileName)
    {
        FileMaker newFile = new FileMaker();
        newFile.prepareFile(fileName, text,true);
        
    }
    public void removeFromFile(String text, String fileName)
    {
        int flag = 1;
        String newText = null;
        ArrayList <Entry> entries = (new ProcessMonitor()).readRegisteredSystemInfo();
        String arr[] = text.split(":");
        for(Entry e:entries)
        {
            if(flag == 1)
            {
                if(!(arr[0].equals(e.getRegName()) && arr[1].equals(e.getServerIP()) && arr[2].equals(e.getServerPort())))
                {
                    newText = e.getRegName()+":"+e.getServerIP()+":"+e.getServerPort()+"\n";
                    createMonitoringFile(newText,fileName);
                    flag = 2;
                }
            }
            else
            {
                if(!(arr[0].equals(e.getRegName()) && arr[1].equals(e.getServerIP()) && arr[2].equals(e.getServerPort())))
                {
                    newText = e.getRegName()+":"+e.getServerIP()+":"+e.getServerPort()+"\n";
                    addToFile(newText,fileName);
                }
            }
            
        }

    }

    public void createMonitoringFile(String text, String fileName)
    {
        FileMaker newFile = new FileMaker();
        newFile.prepareFile(fileName, text,false);
    }

    public void sendReportAttachment(String TO,String text,String fileName){
        
        try{
        FileMaker newFile = new FileMaker();
        newFile.prepareFile(fileName, text,false);
        GmailSender gs = new GmailSender();
        gs.setTO(TO);
        gs.setTEXT("Please find attached the report");
        gs.sendAttachment(fileName);
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }

}
