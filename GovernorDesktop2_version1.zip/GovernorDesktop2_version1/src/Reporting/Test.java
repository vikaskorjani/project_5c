/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Reporting;

/**
 *
 * @author dell
 */
public class Test {

    public static void main(String srgs[])
    {
        Report rp = new Report();
        rp.createMonitoringFile("SOMETEXT", "Proc/NewProc.txt");
    
    }

}
