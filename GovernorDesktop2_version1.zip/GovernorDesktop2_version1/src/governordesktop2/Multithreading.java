package governordesktop2;

import ModuleOrchastrator.GovernorOrchastrator;
import ProcessMonitor.ProcFileEntry;
import ProcessMonitor.ProcessMonitor;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Multithreading implements Runnable
{
    Thread t;
    GovernorOrchastrator orch = new GovernorOrchastrator();
    public boolean finish;
    String regName,serverIP,port;
    MonitoringWindow mw;
    int flag = 0;

   public Multithreading(String tName,MonitoringWindow mwCalled)
   {
      // Create a new, second thread
      System.out.println(tName);
      String arr[] = tName.split(":");
      regName = arr[1];
      serverIP = arr[2];
      port = arr[3];
      mw = mwCalled;
      
      t = new Thread(this, tName);
      System.out.println("Child thread: " + t);
      t.start(); // Start the thread
   }

   // This is the entry point for the second thread.
   public void run()
   {
       String param = "The System is OFFLINE";
       String mod;
       //MonitoringWindow1 mw = new MonitoringWindow1(serverIP, port);

      try {
         while(!finish)
         {
            flag = 0;
            System.out.println("Thread Created : "+t.getName());

            String arr[] = t.getName().split(":");

            if(arr[0].equalsIgnoreCase("SI"))
                try {
                    System.out.println(regName+":"+serverIP+":"+port);
                    param = orch.monitorSystemInfo(regName, serverIP, port);
                } catch (Exception ex) {
                    
                }

            else if(arr[0].equalsIgnoreCase("UI"))
            {
                    try {
                        param = orch.monitorUserInfo(regName, serverIP, port);
                    } catch (Exception ex) {
                        
                    }
                flag = 1;
            }
             else if(arr[0].equalsIgnoreCase("AI"))
                try {
                    param = orch.monitorArchitectureInfo(regName, serverIP, port);
                } catch (Exception ex) {
                    
                }

            else if(arr[0].equalsIgnoreCase("CI"))
                try {
                    param = orch.monitorCoreInfo(regName, serverIP, port);
                } catch (Exception ex) {
                    
                }


             else if(arr[0].equalsIgnoreCase("LP"))
            {
                    try {
                        
                        ArrayList <ProcFileEntry> entries = ProcessMonitor.readProcFileInfo("jatin"+"Proc.txt");
                        param = "PID\tUSER\tPRIORITY\tCPU\tMEMORY\tCOMMAND\n";
                        param = param + "===\t====\t========\t===\t======\t=======\n";
                        for(ProcFileEntry e : entries)
                        {
                            param = param + e.PID+"\t"+e.USER+"\t"+e.PR+"\t"+e.CPU+"\t"+e.MEM+"\t"+e.COMMAND+"\n";

                        }
                        //param = orch.monitorProcesses(regName, serverIP, port);
                    } catch (Exception ex) {
                        
                    }
                flag = 1;
            }
            else if(arr[0].equalsIgnoreCase("PT"))
            {
                    try {
                        param = orch.monitorProcessTree(regName, serverIP, port);
                    } catch (Exception ex) {
                        
                    }
               flag = 1;
            }
             else if(arr[0].equalsIgnoreCase("FS"))
            {
                    try {
                        param = orch.monitorFileSystem(regName, serverIP, port);
                    } catch (Exception ex) {
                        
                    }
               flag = 1;
            }

            mw.printCommandOutput(param, arr[0]);
            // Let the thread sleep for a while.
            if(flag == 1)
                Thread.sleep(2000);
            else
            {
                finish = true;
                System.out.println("Thread killed : "+t.getName());
             }
         }
     } catch (InterruptedException e) {
         System.out.println("Child interrupted.");
     }
     System.out.println("Exiting child thread.");
   }

   private void processThread()
   {
        System.out.println("processThread");
   }
   private void propertiesThread()
   {
    System.out.println("propertiesThread");
   }
}

