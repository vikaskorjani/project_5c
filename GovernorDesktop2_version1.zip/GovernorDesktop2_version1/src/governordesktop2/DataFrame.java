package governordesktop2;

import ProcessMonitor.AutoMonitoringThread;
import ProcessMonitor.Entry;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class DataFrame extends JFrame
{

    static JLabel dynLabel[];
    static JButton bMonitor[];
    static JTextArea jtPassivePolicy[];
    static AutoMonitoringThread[] mt;
    static int row = 0;
    static int index = 0;
    static int textBaseX = 100;
    static int textBaseY = 100;
    static Container panel;
    static int numLabel = 4;

    DataFrame(ArrayList <Entry> entries)
    {
        mt = new AutoMonitoringThread[entries.size()];
        dynLabel = new JLabel[entries.size()*numLabel];
        bMonitor = new JButton[entries.size()];
        jtPassivePolicy = new JTextArea[entries.size()];
        this.setSize(1000, 1000);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = this.getContentPane();
        panel.setLayout(null);

        int i = 0;
        
        for(Entry e : entries)
        {
            
            System.out.println(e.getRegName()+":"+e.getServerIP()+":"+e.getServerPort());
            loadDynField(e.getRegName(),e.getServerIP(),e.getServerPort());
        }


    }


        public static void loadDynField(String regNameParam,String serverIPParam, String serverPortParam)
        {
                int i = 0;
                int x = 0;
                 for(i = row*numLabel;i<(row*numLabel + numLabel);i++)
                {

                    dynLabel[i] = new JLabel();
                    dynLabel[i].setLocation((textBaseX + x*100),(textBaseY + row*20));
                    dynLabel[i].setSize(400, 20);
                    panel.add(dynLabel[i]);
                    
                    if(i%numLabel == 0)
                        dynLabel[i].setText(regNameParam);
                    else if(i%numLabel == 1)
                        dynLabel[i].setText(serverIPParam);
                    else if(i%numLabel == 2)
                        dynLabel[i].setText(serverPortParam);
                    else if (i%numLabel == 3)
                    {
                        dynLabel[i].setText("RETRIEVING STATUS..");
                        dynLabel[i].setForeground(Color.black);
                    }
                    x++;
                }

                jtPassivePolicy[row] = new JTextArea();
                jtPassivePolicy[row].setLocation((textBaseX + x*120), textBaseY + row*20);
                jtPassivePolicy[row].setSize(200, 30);
                
                jtPassivePolicy[row].setText("No Passive policy Violated till now");
                
                jtPassivePolicy[row].setEnabled(true);
                panel.add(jtPassivePolicy[row]);

                bMonitor[row] = new JButton();
                bMonitor[row].setLocation((textBaseX + x*180), textBaseY + row*20);
                bMonitor[row].setSize(100, 20);

                bMonitor[row].addActionListener(new ButtonHandler(regNameParam,serverIPParam,serverPortParam));
                bMonitor[row].setText("MONITOR");
//                bMonitor[row].setEnabled(false);
                panel.add(bMonitor[row]);

                textBaseY = textBaseY + 40;
                row++;

                
                mt[index] = new AutoMonitoringThread(regNameParam,serverIPParam,serverPortParam,index);
                index++;
                
        }

        public static void reflectOfflineResource(int rowIndex)
        {
                dynLabel[rowIndex*numLabel + numLabel - 1].setText("OFFLINE");
                dynLabel[rowIndex*numLabel + numLabel - 1].setForeground(Color.red);
                
                jtPassivePolicy[rowIndex].setText(jtPassivePolicy[rowIndex].getText() +"\n"+ "Resource is Offline");
//                bMonitor[rowIndex].setEnabled(false);
        }

        public static void reflectOnlineResource(int rowIndex)
        {
                dynLabel[rowIndex*numLabel + numLabel - 1].setText("ONLINE");
                dynLabel[rowIndex*numLabel + numLabel - 1].setForeground(Color.green);
                bMonitor[rowIndex].setEnabled(true);
        }

    }


    class ButtonHandler implements ActionListener
    {
        int rowIndex;
        String regName,serverIP,serverPort;

        ButtonHandler(String regNameParam,String serverIPParam,String serverPortParam)
        {
            regName = regNameParam;
            serverIP = serverIPParam;
            serverPort = serverPortParam;
        }

        public void actionPerformed(ActionEvent e)
        {
            (new MonitoringWindow()).displayMonitoring(regName,serverIP,serverPort);
        }


    }

